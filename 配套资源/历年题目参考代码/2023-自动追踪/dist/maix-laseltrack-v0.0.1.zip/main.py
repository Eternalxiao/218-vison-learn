import look_for_data, my_utils
from maix import uart, app, time, camera, display, app, time, image, touchscreen
from queue import Queue
import json, os, cv2
import numpy as np

class BaseInfo:
    # 初始化检测模型
    def __init__(self) -> None:
        # 初始化角点信息查找模块
        self.seek = look_for_data.GetInfor()
        # 实例化串口模块
        self.myutils = my_utils.MyUtils()   
    
    # 寻找角点坐标
    def find_corners(self, img:image.Image) -> dict:
        """
            根据传入的图片进行角点的查找
        """
        return self.seek.look_for_edge(img)

    # 寻找红、绿激光点信息
    def find_laser_spot(self, img:image.Image) -> dict:
        return self.seek.look_for_laser_spot(img)

    # 指定位置显示指定字符串
    def show_info(self, img:image.Image, place: list, content: str, color = image.Color.from_rgb(0, 0, 255), myscale=1):
        img.draw_string(
            int(place[0]), int(place[1]),         # x 和 y 是文字的左上角坐标
            content, # 要写的文字
            color=color, # color 是文字的颜色
            scale=myscale     # 放大字体
        )
        img.draw_cross(
            int(place[0]), int(place[1]),
            image.Color.from_rgb(255, 0, 0), 
            size=5, 
            thickness=2
        )

    # 发送信息
    def send_data(self, data: dict) -> bool:
        if (self.myutils.sending_coordinate_data(data)):
            return True
        return False

def data_processing(serial : uart.UART, bytes_data : bytes):
    """
        指挥函数：分析接受的数据，通过使用 queue.Queue 指挥主线程行为
    """

    print(f"on_received start")
    print("开始解析")

    dir_data = {}   # 储存解析的数据

    try:
        # 将接收到的数据转化为字符串
        all_str_data = bytes_data.decode("utf-8")
        print(f"收到信息{all_str_data=}，开始json解析")
        # 进行字符切片获取到 {} 内的数据
        left_start = all_str_data.find('{')
        right_end = all_str_data.find('}') + 1
        str_data = all_str_data[left_start: right_end]

        dir_data = json.loads(str_data)
    except:
        print(f"json解析错误")  
    else:
        # print(f"json解析成功")

        result = {key: values for key, values in dir_data.items() if values[0] != 0}
        if queue.qsize() < 1:
            queue.put(result)

    # send back
    # while True:
    #     json_data = json.dumps(dir_data)  # 初始化数据为 json 格式
    #     serial.write_str(json_data)
    #     time.sleep_ms(1000) # sleep to make CPU free

def is_in_button(x, y, btn_pos):
    return x > btn_pos[0] and x < btn_pos[0] + btn_pos[2] and y > btn_pos[1] and y < btn_pos[1] + btn_pos[3]

# 初始化串口及指挥线程
device = "/dev/ttyS0"
queue = Queue()
serial = uart.UART(device, 115200)

serial.set_received_callback(data_processing)

# 初始化相机和显示器
cam = camera.Camera(320, 224)
disp = display.Display()        
cam.skip_frames(30)     # 跳过开头的30帧

ts = touchscreen.TouchScreen()  # 初始化触摸屏
data_dir = {}   # 初始化发送数据字典
info = BaseInfo()   # 实例化基本信息类

while not app.need_exit():
    time.fps_start()                         
    img = cam.read()

    img = img.crop(70, 40, 160, 160)
    img_show = img.copy()

    # 得到角点坐标字典
    edge_corners_dict = info.find_corners(img)
    # 得到激光点信息字典
    laser_spot_dict = info.find_laser_spot(img)
    # 得到最后的数据字典
    data_dict = edge_corners_dict | laser_spot_dict
    
    # 图片中批注信息
    for key, value in edge_corners_dict.items():
        info.show_info(img_show, value, f"{key}")

    exit_label = "< Exit"   # draw content
    size = image.string_size(exit_label)    # 确定框大小
    exit_btn_pos = [0, 0, 8*2 + size.width(), 12 * 2 + size.height()]   # rect 的 x, y, w, h
    img_show.draw_string(8, 12, exit_label, image.COLOR_WHITE)   # 显示在屏幕上
    img_show.draw_rect(exit_btn_pos[0], exit_btn_pos[1], exit_btn_pos[2], exit_btn_pos[3],  image.COLOR_WHITE, 2)

    # 判断是否点击
    x, y, pressed = ts.read()
    if is_in_button(x, y, exit_btn_pos):
        app.set_exit_flag(True)
    img_show.draw_circle(x, y, 1, image.Color.from_rgb(255, 255, 255), 2)

    if len(data_dict.keys()) > 1:
        # 发送数据
        print(f"本次发送的keys为：{data_dict.keys()}")
        if (info.send_data(data_dict)):
            print("YES")
        else:
            print("FAIL")

    disp.show(img_show)         # Show image to screen
    fps = time.fps()            # Calculate FPS between last time fps() call and this time call.
    print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}") # print FPS in console 
    time.sleep_ms(500)
