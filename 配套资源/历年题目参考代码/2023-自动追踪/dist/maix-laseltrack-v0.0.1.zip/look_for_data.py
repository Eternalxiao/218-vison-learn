from maix import camera, display, app, image, time
import cv2
import numpy as np


class GetInfor:

    def __init__(self) -> None:
        # 初始化卷积核
        self.kernel3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        self.kernel5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
        self.last_img_cv_gray = None       # 初始化上依次的图片
    def look_for_edge(self, img:image.Image) -> dict:
        
        # 转换为 CV2 格式
        img_raw = image.image2cv(img, copy=False)

        # 转换为灰度 为了方便滤波去除噪点
        img = cv2.cvtColor(img_raw, cv2.COLOR_BGR2GRAY)

        ######################### 图像处理 #########################
        ##### 双边/中值/高斯滤波 #####
        img = cv2.bilateralFilter(img, 9, 10, 10)
    
        ##### 腐蚀/膨胀/开运算/闭运算 #####
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, self.kernel3)


        ##### 边缘检测 #####
        edged = cv2.Canny(img, 50, 150)

        # 效果不好可以再次可以选择性再次进行闭运算，加强效果
        # edged = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel)  
        
        contours, _ = cv2.findContours(edged, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        # print(f"一共寻找到{len(contours)}层\n")
        
        # 初始化用于记录内外层角点的列表
        all_corners = []
        contour_outer = []
        contour_inlayer = []

        # 开始逐层记录，正常应该为四层，我们取第一层和最后一层
        for contour in contours:
            # 计算参数，多边形逼近

            # 获得近似值（与周长相关）：
            epsilon = 0.02 * cv2.arcLength(contour, True)

            """
            cv2.approxPolyDP(curve, epsilon, closed) -- 返回近似后的多边形点集
            # # curve: 输入的轮廓点集
            # # epsilon: 近似精度，值越小，近似越精确，一般与周长有关
            """
            approx = cv2.approxPolyDP(contour, epsilon, True)

            # 记录轮廓角点信息
            if len(approx) == 4:
                # 按照顺序对角点排序（左上，右上，右下，左下）
                corners = approx.reshape((4, 2))
                rect = np.zeros((4, 2), dtype="int")
                points_sum = corners.sum(axis=1)
                rect[0] = corners[np.argmin(points_sum)]
                rect[2] = corners[np.argmax(points_sum)]
                points_diff = np.diff(corners,axis=1)
                rect[1] = corners[np.argmin(points_diff)]
                rect[3] = corners[np.argmax(points_diff)]
                corners = rect

                # 转换为列表存储轮廓角点信息
                all_corners.append(corners.tolist())
        if len(all_corners) == 4:
            # 获取最外侧和最内侧的角点坐标列表
            contour_outer = all_corners[0]
            contour_inlayer = all_corners[-1]

            # 获得最终的结果坐标
            edge_corners_dict = self.average_points(contour_outer, contour_inlayer)

            # 返回结果字典集
            return edge_corners_dict
        return {}
        
    def average_points(self, list1, list2) -> dict:
        """
        计算两个列表中对应坐标点的平均值
        
        参数:
            list1: 第一个点列表，格式为 [[x1,y1], [x2,y2], ...]
            list2: 第二个点列表，格式为 [[x1,y1], [x2,y2], ...]
            
        返回:
            包含平均坐标的新列表，格式为 [[avg_x1, avg_y1], [avg_x2, avg_y2], ...]
        """

        index_dict = {
            0: 'first',
            1: 'second',
            2: 'third',
            3: 'forth'
        }
        i = 0
        result = {}
        for point1, point2 in zip(list1, list2):
            # 计算x坐标平均值
            avg_x = (point1[0] + point2[0]) / 2.0
            # 计算y坐标平均值
            avg_y = (point1[1] + point2[1]) / 2.0
            # 添加到结果列表
            result[index_dict[i]] = (avg_x, avg_y)
            i += 1
        return result

    def look_for_laser_spot(self, img:image.Image) -> dict:

        # 初始化激光点坐标位置变量
        point_x = 0
        point_y = 0

        img_cv = image.image2cv(img, False, False)
        img_cv_gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)

        if self.last_img_cv_gray is None:
            self.last_img_cv_gray = img_cv_gray.copy()

        # 计算差值
        img_diff = cv2.absdiff(img_cv_gray, self.last_img_cv_gray)

        # 二值化处理
        _, img_binary = cv2.threshold(img_diff, 25, 255, cv2.THRESH_BINARY)
        
        # 膨胀处理填充激光点空洞
        img_binary = cv2.dilate(img_binary, self.kernel5, iterations=2)

        # check point 放开注释,应能黑色背景下激光点二值化后的白点
        # img_show = image.cv2image(img_binary, False, False) 
        # disp.show(img_show)
        
        # 更新上一帧的图片为下一次做准备
        self.last_img_cv_gray = img_cv_gray.copy()

        # 初始化用于记录红色和绿色的颜色区域
        all_region = []
        
        # 查找轮廓
        contours, _ = cv2.findContours(img_binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            # 计算轮廓面积
            contour_area = cv2.contourArea(contour)

            # 激光点不大，过滤掉大范围的轮廓
            if contour_area < 350: 
                # 获取激光点轮廓的外接矩形 
                x, y, w, h = cv2.boundingRect(contour)
                x, y, w, h = self.center_scale_rect(x,y,w,h) # 对矩形进行缩放
                all_region.append([x,y,w,h])    # 记录roi区域
        
        if len(all_region) == 2:
            # 对两个 rio 进行区分
            red_region, green_region = self.detect_red_green_regions(img_cv, all_region[0], all_region[1])

            red_point = self.get_centroid(red_region)
            green_point = self.get_centroid(green_region) 
            # 获得质心坐标进行返回
            laser_spot_dict = {
                'red_dot': red_point,
                'green_dot': green_point
            }
            return laser_spot_dict
        return {}

    # 根据 x, y, w, h 得到质心坐标
    def get_centroid(self, region: list) -> list:
        return [(region[0]+region[2]) / 2.0, (region[1]+region[3]) / 2.0]

    # 矩形的中心缩放缩放
    def center_scale_rect(self, x, y, w, h, scale=0.5):
        """
        对矩形进行中心缩放，返回缩放后的位置和尺寸
        
        参数:
        x, y - 矩形左上角坐标
        w, h - 矩形的宽度和高度
        scale - 缩放比例 (1.0表示不变，0.5表示缩小一半，2.0表示放大一倍)
        
        返回:
        (new_x, new_y, new_w, new_h) - 缩放后矩形的左上角坐标和尺寸
        """
        # 计算矩形的中心点
        center_x = x + w / 2
        center_y = y + h / 2
        
        # 计算缩放后的尺寸
        new_w = w * scale
        new_h = h * scale
        
        # 计算缩放后的左上角坐标（基于中心点不变）
        new_x = center_x - new_w / 2
        new_y = center_y - new_h / 2
        
        # 返回缩放后的矩形参数（坐标转为整数）
        return (int(new_x), int(new_y), int(new_w), int(new_h))

    # 红绿区分
    def detect_red_green_regions(self, image, region1, region2):
        """
        检测两个区域中哪个是红色区域，哪个是绿色区域
        
        参数:
        image - 输入图像(BGR格式)
        region1 - 第一个区域(x, y, w, h)
        region2 - 第二个区域(x, y, w, h)
        
        返回:
        (red_region, green_region) - 红色区域和绿色区域的坐标
        """
        # 转换为HSV颜色空间（更容易检测颜色）
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        # 提取两个ROI（感兴趣区域）
        x1, y1, w1, h1 = region1
        roi1 = hsv[y1:y1+h1, x1:x1+w1]
        
        x2, y2, w2, h2 = region2
        roi2 = hsv[y2:y2+h2, x2:x2+w2]
        
        # 定义红色和绿色的HSV范围
        # 红色在HSV中有两个范围（0°和180°附近）
        lower_red1 = np.array([0, 100, 100])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([160, 100, 100])
        upper_red2 = np.array([180, 255, 255])
        
        # 绿色范围
        lower_green = np.array([35, 50, 50])
        upper_green = np.array([85, 255, 255])
        
        # 计算每个区域中的红色像素比例
        red_mask1 = cv2.inRange(roi1, lower_red1, upper_red1)
        red_mask2 = cv2.inRange(roi1, lower_red2, upper_red2)
        red_mask_roi1 = cv2.bitwise_or(red_mask1, red_mask2)
        red_pixels1 = np.sum(red_mask_roi1 > 0)
        total_pixels1 = roi1.shape[0] * roi1.shape[1]
        red_ratio1 = red_pixels1 / total_pixels1 if total_pixels1 > 0 else 0
        
        red_mask1 = cv2.inRange(roi2, lower_red1, upper_red1)
        red_mask2 = cv2.inRange(roi2, lower_red2, upper_red2)
        red_mask_roi2 = cv2.bitwise_or(red_mask1, red_mask2)
        red_pixels2 = np.sum(red_mask_roi2 > 0)
        total_pixels2 = roi2.shape[0] * roi2.shape[1]
        red_ratio2 = red_pixels2 / total_pixels2 if total_pixels2 > 0 else 0
        
        # 计算每个区域中的绿色像素比例
        green_mask_roi1 = cv2.inRange(roi1, lower_green, upper_green)
        green_pixels1 = np.sum(green_mask_roi1 > 0)
        green_ratio1 = green_pixels1 / total_pixels1 if total_pixels1 > 0 else 0
        
        green_mask_roi2 = cv2.inRange(roi2, lower_green, upper_green)
        green_pixels2 = np.sum(green_mask_roi2 > 0)
        green_ratio2 = green_pixels2 / total_pixels2 if total_pixels2 > 0 else 0
        
        # 判断哪个区域是红色，哪个是绿色
        if red_ratio1 > green_ratio1 and green_ratio2 > red_ratio2:
            return region1, region2  # region1是红色，region2是绿色
        elif red_ratio2 > green_ratio2 and green_ratio1 > red_ratio1:
            return region2, region1  # region2是红色，region1是绿色
        else:
            # 如果无法明确区分，返回比例更高的那个
            if red_ratio1 + green_ratio2 > red_ratio2 + green_ratio1:
                return region1, region2
            else:
                return region2, region1


